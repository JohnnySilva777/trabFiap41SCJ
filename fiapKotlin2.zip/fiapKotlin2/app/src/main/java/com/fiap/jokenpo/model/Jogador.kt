package com.fiap.jokenpo.model

/**
 * Created by Johnny on 20/10/2018.
 */
data class Jogador (
        val nome:String,
        val pontos:Int
)