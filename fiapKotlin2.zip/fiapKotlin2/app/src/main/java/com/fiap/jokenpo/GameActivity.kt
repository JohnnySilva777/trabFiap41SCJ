package com.fiap.jokenpo

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_game.*
import java.util.*

class GameActivity : AppCompatActivity() {

    private val delayTela = 1000L
    //Criando uma variavel que ela atribui um numero random que pode ser nulo
    private var numeroAleatorio: Random?=null
    var pontos:Int = 0
    var jogadas:Int = 0
    //VARIAVEIS DE CONTROLE DE ESCOLHA DE JOGADA
    private var PEDRA = 1
    private var TESOURA = 2
    private var PAPEL = 3

    //Funções de Derrota Vitoria e empate
    private fun venceu(){
        //Pego meu TextView Resultado, atribuio um texto onde vou pegar uma string do meu arquivo:
        //values -> strings.xml
        pontos+=2
        jogadas++
        tvResultado!!.text = getString(R.string.venceu)
        //Atribuindo uma cor ao meu texto, onde pego no XML color.
        tvResultado!!.setTextColor(ContextCompat.getColor(this,R.color.vitoria))
        tvPontuacao!!.text = pontos.toString()
        tvTentativas!!.text = jogadas.toString()
    }

    private fun perdeu(){
        jogadas++
        tvResultado!!.text = getString(R.string.derrota)
        tvResultado!!.setTextColor(ContextCompat.getColor(this,R.color.derrota))
        tvTentativas!!.text = jogadas.toString()
        Handler().postDelayed({
            val telaGameOver = Intent(this,GameOverActivity::class.java)
            telaGameOver.putExtra("PONTUACAO", pontos)
            startActivity(telaGameOver)
            finish()
        },delayTela)

    }

    private fun empate(){
        pontos++
        jogadas++
        tvResultado!!.text = getString(R.string.empate)
        tvResultado!!.setTextColor(ContextCompat.getColor(this,R.color.empate))
        tvPontuacao!!.text = pontos.toString()
        tvTentativas!!.text = jogadas.toString()
    }

    //Criando um metodo que sera responsavel por dar as jogadas ao pc e tudo mais
    private fun realizarJogada(jogadaPlayer:Int){
        //Ao chamar minha função eu crio uma variavel que recebe um Media Player (Som), com o audio que escolhi
        //var player = MediaPlayer.create(this,R.raw.jokenpo)
        //Pego a variavel e faço ela tocar.
        //player.start()

        //A jogada PC vai ser uma variavel que recebe o numero aleatorio e que atribui mais 1 pois nossos privates
        //Privates INTs sao 1 2 e 3, mas como falamos que ele vai dar um random em 3 ele retorna (0,1,2)
        var jogadaPC = numeroAleatorio!!.nextInt(3)+1

        //Quando eu tiver qualquer numero do Jogada PC
        when (jogadaPC){
        //Se for Fogo, vale lembrar que ele terá retornado 1
            PEDRA ->{
                //Troco minha iamgem para o charmander
                ivResultadoPC!!.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.pixel_pedra))
                //Qunado eu receber o parametro que eu passar quando chamar a func
                when (jogadaPlayer){
                //Faço as condições, tive que inverter a derrota e vitoria não sei o por que, deve ser por causa dos IDs
                    TESOURA -> perdeu()
                    PEDRA -> empate()
                    PAPEL -> venceu()
                }
            }

            TESOURA -> {
                ivResultadoPC!!.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.pixel_tesoura))
                when(jogadaPlayer){
                    TESOURA -> empate()
                    PEDRA -> venceu()
                    PAPEL -> perdeu()
                }
            }

            PAPEL -> {
                ivResultadoPC!!.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.pixel_papel))
                when(jogadaPlayer){
                    TESOURA -> venceu()
                    PEDRA -> perdeu()
                    PAPEL -> empate()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        //Resetando visualmente o texto de cada textView dos pontos e jogadas
        tvPontuacao!!.text = pontos.toString()
        tvTentativas!!.text = jogadas.toString()

        //Minha variavel recebe um valor random
        numeroAleatorio=Random()

        //Quando o usuario clicar no charmander
        idPedra.setOnClickListener {
            //Ele irá trocar a imagem para o charmander
            ivResultadoPlayer!!.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.pixel_pedra))
            //Vou chamar minha função passando o valor de FOGO para que a função calcule e nos de o resultado.
            realizarJogada(PEDRA)
        }

        idTesoura.setOnClickListener {
            ivResultadoPlayer!!.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.pixel_tesoura))
            realizarJogada(TESOURA)
        }

        idPapel.setOnClickListener {
            ivResultadoPlayer!!.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.pixel_papel))
            realizarJogada(PAPEL)
        }

    }
}
