package com.fiap.jokenpo.api

import com.fiap.jokenpo.model.Jogador
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST


interface JokenpoService {

    @POST("/jokenpo/pontuacao")
    fun enviarPontuacao(@Body pontuacao: Jogador): Call<Void>

    @GET("/jokenpo/pontuacao")
    fun buscarRanking(): Call<List<Jogador>>
}